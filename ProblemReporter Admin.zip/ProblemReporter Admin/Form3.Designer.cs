﻿namespace ProblemReporter_Admin
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Deptlbl = new System.Windows.Forms.Label();
            this.insertbtn = new System.Windows.Forms.Button();
            this.homebtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.deptLoctxt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(257, 118);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(253, 20);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Deptlbl
            // 
            this.Deptlbl.AutoSize = true;
            this.Deptlbl.Location = new System.Drawing.Point(113, 121);
            this.Deptlbl.Name = "Deptlbl";
            this.Deptlbl.Size = new System.Drawing.Size(93, 13);
            this.Deptlbl.TabIndex = 4;
            this.Deptlbl.Text = "Department Name";
            // 
            // insertbtn
            // 
            this.insertbtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.insertbtn.Location = new System.Drawing.Point(257, 222);
            this.insertbtn.Name = "insertbtn";
            this.insertbtn.Size = new System.Drawing.Size(75, 23);
            this.insertbtn.TabIndex = 5;
            this.insertbtn.Text = "Insert";
            this.insertbtn.UseVisualStyleBackColor = false;
            this.insertbtn.Click += new System.EventHandler(this.insertbtn_Click);
            // 
            // homebtn
            // 
            this.homebtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.homebtn.Location = new System.Drawing.Point(435, 222);
            this.homebtn.Name = "homebtn";
            this.homebtn.Size = new System.Drawing.Size(75, 23);
            this.homebtn.TabIndex = 6;
            this.homebtn.Text = "Home";
            this.homebtn.UseVisualStyleBackColor = false;
            this.homebtn.Click += new System.EventHandler(this.homebtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(113, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Department Location";
            // 
            // deptLoctxt
            // 
            this.deptLoctxt.Location = new System.Drawing.Point(257, 172);
            this.deptLoctxt.Name = "deptLoctxt";
            this.deptLoctxt.Size = new System.Drawing.Size(253, 20);
            this.deptLoctxt.TabIndex = 8;
            this.deptLoctxt.TextChanged += new System.EventHandler(this.deptLoctxt_TextChanged);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.deptLoctxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.homebtn);
            this.Controls.Add(this.insertbtn);
            this.Controls.Add(this.Deptlbl);
            this.Controls.Add(this.textBox1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label Deptlbl;
        private System.Windows.Forms.Button insertbtn;
        private System.Windows.Forms.Button homebtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox deptLoctxt;
    }
}