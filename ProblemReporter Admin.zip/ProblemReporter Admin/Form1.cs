﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace ProblemReporter_Admin
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void txtUname_TextChanged(object sender, EventArgs e)
        {

        }

        string conn = ("Data Source =127.0.0.1;username=root;password= ; database= complaints;");
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtUname.Text=="" && txtPasss.Text=="")
                {
                    MessageBox.Show(" Please Enter the Username and Password");
                }

                else
                {
                    MySqlConnection con = new MySqlConnection(conn);
                    MySqlCommand cmd = new MySqlCommand("select * from Administrator where (Admin_ID=@username and Password=@userpass)  ", con);
                    cmd.Parameters.AddWithValue("@username", txtUname.Text);
                    cmd.Parameters.AddWithValue("@userpass", txtPasss.Text);

                    con.Open();
                    MySqlDataAdapter adpt = new MySqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    adpt.Fill(ds);
                    con.Close();

                    int count = ds.Tables[0].Rows.Count;

                    if (count ==1)
                    {

                        MessageBox.Show(" Sucessfully logged in ");

                        console newform = new console();
                        this.Hide();
                        newform.ShowDialog();
                       

                    }
                    else
                    {

                        MessageBox.Show(" Invalid username and password ");
                    }

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }
    }
}
