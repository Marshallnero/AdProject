﻿namespace ProblemReporter_Admin
{
    partial class console
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.GroupBox groupBox1;
            this.MainScreen = new System.Windows.Forms.TabControl();
            this.reportsTp = new System.Windows.Forms.TabPage();
            this.messageTp = new System.Windows.Forms.TabPage();
            this.studentsTp = new System.Windows.Forms.TabPage();
            this.DsTp = new System.Windows.Forms.TabPage();
            this.ReportslistBox = new System.Windows.Forms.ListBox();
            this.reportsbtn = new System.Windows.Forms.Button();
            this.adduserTb = new System.Windows.Forms.TabPage();
            this.fnametxt = new System.Windows.Forms.TextBox();
            this.lnametxt = new System.Windows.Forms.TextBox();
            this.idnumtxt = new System.Windows.Forms.TextBox();
            this.phonetxt = new System.Windows.Forms.TextBox();
            this.newpasstxt = new System.Windows.Forms.TextBox();
            this.fnamelbl = new System.Windows.Forms.Label();
            this.lnamelbl = new System.Windows.Forms.Label();
            this.IDnumlbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.newpasslbl = new System.Windows.Forms.Label();
            this.stuRb = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.conpasslbl = new System.Windows.Forms.Label();
            this.conPasstxt = new System.Windows.Forms.TextBox();
            this.add = new System.Windows.Forms.Button();
            this.submitbtn = new System.Windows.Forms.Button();
            this.deptnametxt = new System.Windows.Forms.TextBox();
            this.deptname = new System.Windows.Forms.Label();
            groupBox1 = new System.Windows.Forms.GroupBox();
            this.MainScreen.SuspendLayout();
            this.reportsTp.SuspendLayout();
            this.DsTp.SuspendLayout();
            this.adduserTb.SuspendLayout();
            groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainScreen
            // 
            this.MainScreen.Controls.Add(this.reportsTp);
            this.MainScreen.Controls.Add(this.messageTp);
            this.MainScreen.Controls.Add(this.studentsTp);
            this.MainScreen.Controls.Add(this.DsTp);
            this.MainScreen.Controls.Add(this.adduserTb);
            this.MainScreen.Location = new System.Drawing.Point(0, 0);
            this.MainScreen.Name = "MainScreen";
            this.MainScreen.SelectedIndex = 0;
            this.MainScreen.Size = new System.Drawing.Size(802, 426);
            this.MainScreen.TabIndex = 0;
            // 
            // reportsTp
            // 
            this.reportsTp.BackColor = System.Drawing.Color.Turquoise;
            this.reportsTp.Controls.Add(this.reportsbtn);
            this.reportsTp.Controls.Add(this.ReportslistBox);
            this.reportsTp.Location = new System.Drawing.Point(4, 22);
            this.reportsTp.Name = "reportsTp";
            this.reportsTp.Padding = new System.Windows.Forms.Padding(3);
            this.reportsTp.Size = new System.Drawing.Size(794, 400);
            this.reportsTp.TabIndex = 0;
            this.reportsTp.Text = "Reports";
            this.reportsTp.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // messageTp
            // 
            this.messageTp.Location = new System.Drawing.Point(4, 22);
            this.messageTp.Name = "messageTp";
            this.messageTp.Padding = new System.Windows.Forms.Padding(3);
            this.messageTp.Size = new System.Drawing.Size(794, 400);
            this.messageTp.TabIndex = 1;
            this.messageTp.Text = "Messages";
            this.messageTp.UseVisualStyleBackColor = true;
            this.messageTp.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // studentsTp
            // 
            this.studentsTp.Location = new System.Drawing.Point(4, 22);
            this.studentsTp.Name = "studentsTp";
            this.studentsTp.Padding = new System.Windows.Forms.Padding(3);
            this.studentsTp.Size = new System.Drawing.Size(794, 400);
            this.studentsTp.TabIndex = 2;
            this.studentsTp.Text = "Students";
            this.studentsTp.UseVisualStyleBackColor = true;
            this.studentsTp.Click += new System.EventHandler(this.studentsTp_Click);
            // 
            // DsTp
            // 
            this.DsTp.BackColor = System.Drawing.Color.Turquoise;
            this.DsTp.Controls.Add(this.add);
            this.DsTp.Location = new System.Drawing.Point(4, 22);
            this.DsTp.Name = "DsTp";
            this.DsTp.Padding = new System.Windows.Forms.Padding(3);
            this.DsTp.Size = new System.Drawing.Size(794, 400);
            this.DsTp.TabIndex = 3;
            this.DsTp.Text = "Department Status";
            this.DsTp.Click += new System.EventHandler(this.DsTp_Click);
            // 
            // ReportslistBox
            // 
            this.ReportslistBox.FormattingEnabled = true;
            this.ReportslistBox.Location = new System.Drawing.Point(0, 0);
            this.ReportslistBox.Name = "ReportslistBox";
            this.ReportslistBox.Size = new System.Drawing.Size(650, 342);
            this.ReportslistBox.TabIndex = 0;
            this.ReportslistBox.SelectedIndexChanged += new System.EventHandler(this.ReportslistBox_SelectedIndexChanged);
            // 
            // reportsbtn
            // 
            this.reportsbtn.Location = new System.Drawing.Point(8, 348);
            this.reportsbtn.Name = "reportsbtn";
            this.reportsbtn.Size = new System.Drawing.Size(106, 43);
            this.reportsbtn.TabIndex = 1;
            this.reportsbtn.Text = "Load Reports";
            this.reportsbtn.UseVisualStyleBackColor = true;
            this.reportsbtn.Click += new System.EventHandler(this.reportsbtn_Click);
            // 
            // adduserTb
            // 
            this.adduserTb.BackColor = System.Drawing.Color.Turquoise;
            this.adduserTb.Controls.Add(this.deptname);
            this.adduserTb.Controls.Add(this.deptnametxt);
            this.adduserTb.Controls.Add(this.submitbtn);
            this.adduserTb.Controls.Add(this.conPasstxt);
            this.adduserTb.Controls.Add(this.conpasslbl);
            this.adduserTb.Controls.Add(groupBox1);
            this.adduserTb.Controls.Add(this.newpasslbl);
            this.adduserTb.Controls.Add(this.label4);
            this.adduserTb.Controls.Add(this.IDnumlbl);
            this.adduserTb.Controls.Add(this.lnamelbl);
            this.adduserTb.Controls.Add(this.fnamelbl);
            this.adduserTb.Controls.Add(this.newpasstxt);
            this.adduserTb.Controls.Add(this.phonetxt);
            this.adduserTb.Controls.Add(this.idnumtxt);
            this.adduserTb.Controls.Add(this.lnametxt);
            this.adduserTb.Controls.Add(this.fnametxt);
            this.adduserTb.ForeColor = System.Drawing.Color.Black;
            this.adduserTb.Location = new System.Drawing.Point(4, 22);
            this.adduserTb.Name = "adduserTb";
            this.adduserTb.Padding = new System.Windows.Forms.Padding(3);
            this.adduserTb.Size = new System.Drawing.Size(794, 400);
            this.adduserTb.TabIndex = 4;
            this.adduserTb.Text = "Add User";
            // 
            // fnametxt
            // 
            this.fnametxt.Location = new System.Drawing.Point(249, 70);
            this.fnametxt.Name = "fnametxt";
            this.fnametxt.Size = new System.Drawing.Size(345, 20);
            this.fnametxt.TabIndex = 2;
            // 
            // lnametxt
            // 
            this.lnametxt.Location = new System.Drawing.Point(249, 124);
            this.lnametxt.Name = "lnametxt";
            this.lnametxt.Size = new System.Drawing.Size(345, 20);
            this.lnametxt.TabIndex = 3;
            // 
            // idnumtxt
            // 
            this.idnumtxt.Location = new System.Drawing.Point(249, 24);
            this.idnumtxt.Name = "idnumtxt";
            this.idnumtxt.Size = new System.Drawing.Size(345, 20);
            this.idnumtxt.TabIndex = 1;
            this.idnumtxt.TextChanged += new System.EventHandler(this.idnumtxt_TextChanged);
            // 
            // phonetxt
            // 
            this.phonetxt.Location = new System.Drawing.Point(249, 174);
            this.phonetxt.Name = "phonetxt";
            this.phonetxt.Size = new System.Drawing.Size(345, 20);
            this.phonetxt.TabIndex = 4;
            // 
            // newpasstxt
            // 
            this.newpasstxt.Location = new System.Drawing.Point(249, 250);
            this.newpasstxt.Name = "newpasstxt";
            this.newpasstxt.PasswordChar = '*';
            this.newpasstxt.Size = new System.Drawing.Size(345, 20);
            this.newpasstxt.TabIndex = 6;
            this.newpasstxt.TextChanged += new System.EventHandler(this.newpasstxt_TextChanged);
            // 
            // fnamelbl
            // 
            this.fnamelbl.AutoSize = true;
            this.fnamelbl.ForeColor = System.Drawing.Color.Black;
            this.fnamelbl.Location = new System.Drawing.Point(89, 77);
            this.fnamelbl.Name = "fnamelbl";
            this.fnamelbl.Size = new System.Drawing.Size(57, 13);
            this.fnamelbl.TabIndex = 5;
            this.fnamelbl.Text = "First Name";
            // 
            // lnamelbl
            // 
            this.lnamelbl.AutoSize = true;
            this.lnamelbl.ForeColor = System.Drawing.Color.Black;
            this.lnamelbl.Location = new System.Drawing.Point(89, 124);
            this.lnamelbl.Name = "lnamelbl";
            this.lnamelbl.Size = new System.Drawing.Size(58, 13);
            this.lnamelbl.TabIndex = 6;
            this.lnamelbl.Text = "Last Name";
            // 
            // IDnumlbl
            // 
            this.IDnumlbl.AutoSize = true;
            this.IDnumlbl.ForeColor = System.Drawing.Color.Black;
            this.IDnumlbl.Location = new System.Drawing.Point(89, 31);
            this.IDnumlbl.Name = "IDnumlbl";
            this.IDnumlbl.Size = new System.Drawing.Size(58, 13);
            this.IDnumlbl.TabIndex = 7;
            this.IDnumlbl.Text = "ID Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(89, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Phone Number";
            // 
            // newpasslbl
            // 
            this.newpasslbl.AutoSize = true;
            this.newpasslbl.ForeColor = System.Drawing.Color.Black;
            this.newpasslbl.Location = new System.Drawing.Point(89, 253);
            this.newpasslbl.Name = "newpasslbl";
            this.newpasslbl.Size = new System.Drawing.Size(78, 13);
            this.newpasslbl.TabIndex = 9;
            this.newpasslbl.Text = "New Password";
            // 
            // stuRb
            // 
            this.stuRb.AutoSize = true;
            this.stuRb.ForeColor = System.Drawing.Color.Black;
            this.stuRb.Location = new System.Drawing.Point(19, 34);
            this.stuRb.Name = "stuRb";
            this.stuRb.Size = new System.Drawing.Size(62, 17);
            this.stuRb.TabIndex = 9;
            this.stuRb.TabStop = true;
            this.stuRb.Text = "Student";
            this.stuRb.UseVisualStyleBackColor = true;
            this.stuRb.CheckedChanged += new System.EventHandler(this.stuRb_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.ForeColor = System.Drawing.Color.Black;
            this.radioButton2.Location = new System.Drawing.Point(19, 67);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(85, 17);
            this.radioButton2.TabIndex = 10;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Administrator";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(this.stuRb);
            groupBox1.Controls.Add(this.radioButton2);
            groupBox1.Location = new System.Drawing.Point(627, 303);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new System.Drawing.Size(123, 94);
            groupBox1.TabIndex = 12;
            groupBox1.TabStop = false;
            groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // conpasslbl
            // 
            this.conpasslbl.AutoSize = true;
            this.conpasslbl.ForeColor = System.Drawing.Color.Black;
            this.conpasslbl.Location = new System.Drawing.Point(89, 291);
            this.conpasslbl.Name = "conpasslbl";
            this.conpasslbl.Size = new System.Drawing.Size(91, 13);
            this.conpasslbl.TabIndex = 13;
            this.conpasslbl.Text = "Confirm Password";
            // 
            // conPasstxt
            // 
            this.conPasstxt.Location = new System.Drawing.Point(249, 291);
            this.conPasstxt.Name = "conPasstxt";
            this.conPasstxt.PasswordChar = '*';
            this.conPasstxt.Size = new System.Drawing.Size(345, 20);
            this.conPasstxt.TabIndex = 7;
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(199, 323);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(113, 44);
            this.add.TabIndex = 0;
            this.add.Text = "Add Department";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // submitbtn
            // 
            this.submitbtn.ForeColor = System.Drawing.Color.Black;
            this.submitbtn.Location = new System.Drawing.Point(249, 331);
            this.submitbtn.Name = "submitbtn";
            this.submitbtn.Size = new System.Drawing.Size(75, 23);
            this.submitbtn.TabIndex = 8;
            this.submitbtn.Text = "Submit";
            this.submitbtn.UseVisualStyleBackColor = true;
            this.submitbtn.Click += new System.EventHandler(this.submitbtn_Click);
            // 
            // deptnametxt
            // 
            this.deptnametxt.Location = new System.Drawing.Point(249, 211);
            this.deptnametxt.Name = "deptnametxt";
            this.deptnametxt.Size = new System.Drawing.Size(345, 20);
            this.deptnametxt.TabIndex = 5;
            this.deptnametxt.TextChanged += new System.EventHandler(this.deptnametxt_TextChanged);
            // 
            // deptname
            // 
            this.deptname.AutoSize = true;
            this.deptname.ForeColor = System.Drawing.Color.Black;
            this.deptname.Location = new System.Drawing.Point(89, 211);
            this.deptname.Name = "deptname";
            this.deptname.Size = new System.Drawing.Size(93, 13);
            this.deptname.TabIndex = 17;
            this.deptname.Text = "Department Name";
            // 
            // console
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MainScreen);
            this.Name = "console";
            this.Text = "Console";
            this.MainScreen.ResumeLayout(false);
            this.reportsTp.ResumeLayout(false);
            this.DsTp.ResumeLayout(false);
            this.adduserTb.ResumeLayout(false);
            this.adduserTb.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl MainScreen;
        private System.Windows.Forms.TabPage reportsTp;
        private System.Windows.Forms.TabPage messageTp;
        private System.Windows.Forms.TabPage studentsTp;
        private System.Windows.Forms.TabPage DsTp;
        private System.Windows.Forms.Button reportsbtn;
        private System.Windows.Forms.ListBox ReportslistBox;
        private System.Windows.Forms.TabPage adduserTb;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton stuRb;
        private System.Windows.Forms.Label newpasslbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label IDnumlbl;
        private System.Windows.Forms.Label lnamelbl;
        private System.Windows.Forms.Label fnamelbl;
        private System.Windows.Forms.TextBox newpasstxt;
        private System.Windows.Forms.TextBox phonetxt;
        private System.Windows.Forms.TextBox idnumtxt;
        private System.Windows.Forms.TextBox lnametxt;
        private System.Windows.Forms.TextBox fnametxt;
        private System.Windows.Forms.TextBox conPasstxt;
        private System.Windows.Forms.Label conpasslbl;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button submitbtn;
        private System.Windows.Forms.Label deptname;
        private System.Windows.Forms.TextBox deptnametxt;
    }
}