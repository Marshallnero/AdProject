﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;

namespace ProblemReporter_Admin
{
    public partial class console : Form
    {
        public console()
        {
            InitializeComponent();
        }


        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void DsTp_Click(object sender, EventArgs e)
        {

        }

        private void studentsTp_Click(object sender, EventArgs e)
        {

        }

        private void ReportslistBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void reportsbtn_Click(object sender, EventArgs e)
        {
            //connect to database and list all reports when the button is clicked
            string conn = ("Data Source =127.0.0.1;username=root;password= ; database= complaints;");

            DataTable records = new DataTable();
            MySqlDataAdapter list = new MySqlDataAdapter( "Select * from complaint", conn);
            list.Fill(records);

            foreach (DataRow dr in records.Rows)
            {
                ReportslistBox.Items.Add(dr["Problem"].ToString());

            }


        }

        private void stuRb_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void add_Click(object sender, EventArgs e)
        {
            Form3 add_department = new Form3(); // Instantiate a Form3 object.
            add_department.Show(); // Show Form3 and
            this.Close(); // closes the console instance.
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void submitbtn_Click(object sender, EventArgs e)
        {
           
            if (newpasstxt.Text == conPasstxt.Text && newpasstxt.Text !="" || conPasstxt.Text !="")
            {


                string conn = ("Data Source = 127.0.0.1;username=root;password= ; database= complaints;");
                if (stuRb.Checked == true)
                {
                    string Query = "insert into student (Student_ID,FirstName,LastName,Phone,Password) values('"+this.idnumtxt.Text+"','"+this.fnametxt.Text+"','"+this.lnametxt.Text+"','"+this.phonetxt.Text+"','"+this.newpasstxt.Text+"');";

                    MySqlConnection link = new MySqlConnection(conn);
                    //This is command class which will handle the query and connection object.  
                    MySqlCommand update = new MySqlCommand(Query, link);
                    MySqlDataReader MyReader2;
                    link.Open();
                    MyReader2 = update.ExecuteReader();     // Here our query will be executed and data saved into the database.  
                    MessageBox.Show("Save Data");
                    while (MyReader2.Read())
                    {
                    }
                    link.Close();
                }

                else
                {
                    if (radioButton2.Checked == true)
                    {
                        string Query = "insert into administrator (Admin_ID,DepartmentName,FirstName,LastName,Phone,Password)  values('" + this.idnumtxt.Text + "','" + this.deptname.Text + "','" + this.fnametxt.Text + "','" + this.lnametxt.Text + "','" + this.phonetxt.Text + "' ,'" + this.newpasstxt.Text + "');";

                        MySqlConnection link = new MySqlConnection(conn);
                        //This is command class which will handle the query and connection object.  
                        MySqlCommand update = new MySqlCommand(Query, link);
                        MySqlDataReader MyReader2;
                        link.Open();
                        MyReader2 = update.ExecuteReader();     // Here our query will be executed and data saved into the database.  
                        MessageBox.Show("Save Data");
                        while (MyReader2.Read())
                        {
                        }
                        link.Close();
                    }

                    else
                    {
                        MessageBox.Show("Please select Student or Administrator");
                    }
                }
            }
            else
            {
                MessageBox.Show("Both passwords must be the same");
            }
        }

        private void idnumtxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void newpasstxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void deptnametxt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
