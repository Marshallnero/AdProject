﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProblemReporter_Admin
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void homebtn_Click(object sender, EventArgs e)
        {
            console home = new console(); // Instantiate a console object.
            home.Show(); // Show console and
            this.Close(); // closes the Form3 instance.
        }

        private void insertbtn_Click(object sender, EventArgs e)
        {
            
                string conn = ("Data Source =127.0.0.1;username=root;password= ; database= complaints;");
                string Query = "insert into department (Name,Location) values('" + this.textBox1.Text + "','" + deptLoctxt.Text + "');";

                MySqlConnection link = new MySqlConnection(conn);
                //This is command class which will handle the query and connection object.  
                MySqlCommand update = new MySqlCommand(Query, link);
                MySqlDataReader MyReader2;
                link.Open();
                MyReader2 = update.ExecuteReader();     // Here our query will be executed and data saved into the database.  
                MessageBox.Show("Save Data");
                while (MyReader2.Read())
                {
                }
                link.Close();
            
        }
    

        private void deptLoctxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
