﻿namespace ProblemReporter_Admin
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtUname = new System.Windows.Forms.TextBox();
            this.txtPasss = new System.Windows.Forms.TextBox();
            this.Uname_lbl1 = new System.Windows.Forms.Label();
            this.Password_lbl2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtUname
            // 
            this.txtUname.Location = new System.Drawing.Point(128, 40);
            this.txtUname.Name = "txtUname";
            this.txtUname.Size = new System.Drawing.Size(235, 20);
            this.txtUname.TabIndex = 0;
            this.txtUname.TextChanged += new System.EventHandler(this.txtUname_TextChanged);
            // 
            // txtPasss
            // 
            this.txtPasss.Location = new System.Drawing.Point(128, 112);
            this.txtPasss.Name = "txtPasss";
            this.txtPasss.PasswordChar = '*';
            this.txtPasss.Size = new System.Drawing.Size(235, 20);
            this.txtPasss.TabIndex = 1;
            // 
            // Uname_lbl1
            // 
            this.Uname_lbl1.AutoSize = true;
            this.Uname_lbl1.Location = new System.Drawing.Point(42, 40);
            this.Uname_lbl1.Name = "Uname_lbl1";
            this.Uname_lbl1.Size = new System.Drawing.Size(60, 13);
            this.Uname_lbl1.TabIndex = 2;
            this.Uname_lbl1.Text = "User Name";
            // 
            // Password_lbl2
            // 
            this.Password_lbl2.AutoSize = true;
            this.Password_lbl2.Location = new System.Drawing.Point(42, 112);
            this.Password_lbl2.Name = "Password_lbl2";
            this.Password_lbl2.Size = new System.Drawing.Size(53, 13);
            this.Password_lbl2.TabIndex = 3;
            this.Password_lbl2.Text = "Password";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(199, 181);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 25);
            this.button1.TabIndex = 4;
            this.button1.Text = "Login";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.button1_KeyDown);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Password_lbl2);
            this.Controls.Add(this.Uname_lbl1);
            this.Controls.Add(this.txtPasss);
            this.Controls.Add(this.txtUname);
            this.Name = "Login";
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtUname;
        private System.Windows.Forms.TextBox txtPasss;
        private System.Windows.Forms.Label Uname_lbl1;
        private System.Windows.Forms.Label Password_lbl2;
        private System.Windows.Forms.Button button1;
    }
}

